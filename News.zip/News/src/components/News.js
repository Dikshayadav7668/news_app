import React, { Component } from 'react'
import NewsItem from './NewsItem'
import PropTypes from 'prop-types'
import InfiniteScroll from "react-infinite-scroll-component";




export class News extends Component {

  static defaultProps = {
    country:'in',
    pageSize:8
  }
  
  static propTypes = {
    country:PropTypes.string,
    pageSize:PropTypes.number,
    category:PropTypes.string


  }

   capitalizefirstletter = (string) =>{
    return string.charAt(0).toUpperCase() + string.slice(1);
   }
  

  constructor(props){
    super(props);
    console.log("Hello I am a constructor");
    this.state = {
      articles:[],
      loading:false,
      page:1,
      totalResults:0

    }
    document.title = `${this.capitalizefirstletter(this.props.category)}-NewsMonkey`;
  }
 
 async componentDidMount(){
  this.props.setProgress(30);
   let url=`https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=7a23c93d3f8d4a65a9d5415341bb9132&pageSize=${this.props.pageSize}`;
    let data =  await fetch(url);
    let paresdData = await data.json()
    this.props.setProgress(70);
    console.log(paresdData);
    this.setState({articles:paresdData.articles,totalResults:paresdData.totalResults})
    this.props.setProgress(100);
    
 }

/* handlePrevClick  = async ()=>{
  console.log("Previous Click");
  let url=`https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=7a23c93d3f8d4a65a9d5415341bb9132&page=${this.state.page-1}&pageSize=${this.props.pageSize}`;
  let data =  await fetch(url);
  let paresdData = await data.json()
  console.log(paresdData);
  this.setState({
    page: this.state.page-1,
    articles: paresdData.articles
  })


 }
 handleNextClick = async ()=>{
  console.log("Next Click");
  if(this.state.page+1>Math.ceil(this.state.totalResults/this.props.pageSize)){

  }
  else
  {
    
    let url=`https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=7a23c93d3f8d4a65a9d5415341bb9132&page=${this.state.page+1}&pageSize=${this.props.pageSize}`;
    let data =  await fetch(url);
    let paresdData = await data.json()
    console.log(paresdData);
    this.setState({
      page: this.state.page+1,
      articles: paresdData.articles
    })
 
  }
  

 }
  */
 fetchMoreData = async () => {
  let url=`https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=7a23c93d3f8d4a65a9d5415341bb9132&pageSize=${this.props.pageSize}`;
    let data =  await fetch(url);
    let paresdData = await data.json()
    this.setState({
      
      articles:this.state.articles.concat(paresdData.articles),
      totalResults:paresdData.totalResults,
      loading:false
    })
 
  };
  

  render() {
    return (
      <div>
        <div className="container-fluid my-3">
            <h1 className="text-center " style={{marginTop:'90px'}}>NewsMonkey- Top {this.capitalizefirstletter(this.props.category)} Headlines</h1>

                <InfiniteScroll
          dataLength={this.state.articles.length}
          next={this.fetchMoreData}
          hasMore={this.state.articles.length !== this.state.totalResults}
          loader={<h4>Loading...</h4>}
        >
          
            <div className="row">
              {this.state.articles.map((element)=>{
                return <div className="col-md-4" key={element.url}>
                <NewsItem title={element.title} description={element.description} imageUrl={element.urlToImage} newsUrl={element.url} author={element.author} date={element.publishedAt} source={element.source.name}/>
                </div>

              })}
              </div>
              </InfiniteScroll>
             
                
          
        

            </div>
            
        </div>



    
    )
  }
}

export default News
