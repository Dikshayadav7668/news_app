import './App.css';

import React, {Component} from 'react';
import Navbar from './components/Navbar';
import News from './components/News';
import {
  BrowserRouter as Router,
  Routes,
  Route,
}from "react-router-dom"
import LoadingBar from 'react-top-loading-bar'
export default class App extends Component {
  state={
    progress:0
  }
  setProgress=(progress)=>{
    this.setState({progress:progress})
  }
  render() {
    return (
      <div>
        <Router>
        <Navbar/>
        <LoadingBar
        color='#f11946'
        progress={this.state.progress}
      
      />
        <Routes>
          <Route path="/" element={<News setProgress = {this.setProgress}  key='general' pageSize={30} country="in" category="general"/>}></Route>
          <Route path="/Business" element={ <News setProgress = {this.setProgress}  key='business'  pageSize={30} country="in" category="business"/>}></Route>
          <Route path="/Entertainment" element={<News setProgress = {this.setProgress}  key='entertainment'  pageSize={30} country="in" category="entertainment"/>}></Route>
          <Route path="/General" element={ <News setProgress = {this.setProgress}  key='general'  pageSize={30} country="in" category="general"/>}></Route>
          <Route path="/Health" element={ <News setProgress = {this.setProgress}  key='health'  pageSize={30} country="in" category="health"/>}></Route>
          <Route path="/Science" element={ <News setProgress = {this.setProgress}  key='science'  pageSize={30} country="in" category="science"/>}></Route>
          <Route path="/Sport" element={ <News setProgress = {this.setProgress}  key='sport'  pageSize={30} country="in" category="sport"/>}></Route>
          <Route path="/Technology" element={ <News setProgress = {this.setProgress}   key='technology}>' pageSize={30} country="in" category="technology"/>}></Route>

        </Routes>
        </Router>
      </div>
    )
  }
}